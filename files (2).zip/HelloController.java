package com.example.helloworld;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {

    // GET /  ->  raiz
    @GetMapping("/")
    public String root() {
        return "Hello World!";
    }

    // GET /hello
    @GetMapping("/hello")
    public String hello() {
        return "Hello World!";
    }

    // GET /health  ->  util para health check do load balancer depois
    @GetMapping("/health")
    public String health() {
        return "OK";
    }
}
