# helloworld — Spring Boot leve para o exercício de ECS

App mínima criada porque a imagem do `hello-api` ficou pesada (tinha JPA,
driver MySQL e SDK da AWS). Aqui só existe o endpoint hello world.

## O que deixa a imagem leve

1. **Uma dependência só**: `spring-boot-starter-web`. Sem JPA, sem banco,
   sem SDK AWS.
2. **Build multi-stage**: o Maven/JDK ficam só na etapa de build e não vão
   para a imagem final.
3. **Base JRE Alpine**: `eclipse-temurin:21-jre-alpine` (~70 MB) no lugar do
   `21-jdk` (~450 MB).
4. **JVM enxuta**: `-Xmx256m`, o que permite a task ECS rodar em **512 MB**
   em vez dos 2 GB que o app pesado exigia.

## Estrutura

```
helloworld/
├── pom.xml
├── Dockerfile
├── .dockerignore
├── deploy.sh
├── task-definition.json
└── src/main/
    ├── java/com/example/helloworld/
    │   ├── HelloworldApplication.java
    │   └── HelloController.java
    └── resources/application.properties
```

## Endpoints

| Método | Rota | Resposta |
|---|---|---|
| GET | `/` | Hello World! |
| GET | `/hello` | Hello World! |
| GET | `/health` | OK |

## Rodar local (opcional, pra conferir antes)

```bash
mvn spring-boot:run
# em outra aba:
curl http://localhost:8080/hello
```

## Deploy completo (build -> ECR -> ECS)

Na raiz do projeto:

```bash
chmod +x deploy.sh
./deploy.sh
```

O script faz tudo em sequência: compila o jar, cria o repositório no ECR,
faz login, builda e dá push da imagem, cria o log group, a execution role,
registra a task definition, cria o cluster, monta a rede (VPC default +
security group liberando 8080) e sobe o service Fargate com IP público.
No fim ele imprime como achar o IP e o `curl` de teste.

## Antes de rodar, confira

- **Conta/região**: o script e o `task-definition.json` apontam para
  `us-east-2` / `840986438181`. Se a aula for na conta do instrutor
  (ex.: `447197207642` / `sa-east-1`), troque `REGION` e `ACCOUNT_ID` no
  topo do `deploy.sh` **e** os campos `image`/`executionRoleArn` no
  `task-definition.json`.
- **IAM**: o usuário precisa de permissão para ECR, ECS, IAM (criar a role
  e `iam:PassRole`), CloudWatch Logs e EC2 (rede). Sem `iam:PassRole` na
  `ecsTaskExecutionRole`, a criação do service falha.

## Atualizar depois de mudar o código

```bash
./deploy.sh   # rebuilda, dá push e força novo deployment automaticamente
```
