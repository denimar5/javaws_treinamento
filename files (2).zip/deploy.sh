#!/usr/bin/env bash
# ============================================================
# helloworld: build -> ECR -> ECS Fargate (de ponta a ponta)
# Rode na raiz do projeto (onde estao o pom.xml e o Dockerfile).
# ============================================================
set -e

# ---------- PARAMETROS (ajuste se a aula for em outra conta/regiao) ----------
REGION="us-east-2"
ACCOUNT_ID="840986438181"
REPO="helloworld"
CLUSTER="helloworld-cluster"
SERVICE="helloworld-service"
FAMILY="helloworld-task"
LOG_GROUP="/ecs/helloworld"
APP_PORT=8080
# Se o exercicio for na conta do instrutor, troque REGION/ACCOUNT_ID acima
# e ajuste tambem a "image"/"executionRoleArn" no task-definition.json.
# ----------------------------------------------------------------------------

ECR="${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com/${REPO}"

echo "==> 1) Build do jar..."
mvn clean package -DskipTests
ls -1 target/*.jar | grep -v '\.original$'

echo "==> 2) Criando repositorio no ECR (ignora se existir)..."
aws ecr create-repository --repository-name "$REPO" --region "$REGION" \
  >/dev/null 2>&1 || echo "    (repo ja existe)"

echo "==> 3) Login no ECR..."
aws ecr get-login-password --region "$REGION" \
  | docker login --username AWS --password-stdin "$ECR"

echo "==> 4) Build da imagem (amd64) e push..."
docker buildx build --platform linux/amd64 -t "$REPO" --load .
docker tag "$REPO:latest" "$ECR:latest"
docker push "$ECR:latest"

echo "==> 5) Log group no CloudWatch..."
aws logs create-log-group --log-group-name "$LOG_GROUP" --region "$REGION" \
  2>/dev/null || echo "    (log group ja existe)"

echo "==> 6) Execution role do ECS..."
cat > /tmp/ecs-trust.json << 'EOF'
{ "Version": "2012-10-17",
  "Statement": [ { "Effect": "Allow",
    "Principal": { "Service": "ecs-tasks.amazonaws.com" },
    "Action": "sts:AssumeRole" } ] }
EOF
aws iam create-role --role-name ecsTaskExecutionRole \
  --assume-role-policy-document file:///tmp/ecs-trust.json 2>/dev/null \
  || echo "    (role ja existe)"
aws iam attach-role-policy --role-name ecsTaskExecutionRole \
  --policy-arn arn:aws:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy \
  2>/dev/null || true

echo "==> 7) Registrando a task definition..."
aws ecs register-task-definition \
  --cli-input-json file://task-definition.json --region "$REGION" >/dev/null

echo "==> 8) Cluster..."
aws ecs create-cluster --cluster-name "$CLUSTER" --region "$REGION" >/dev/null || true

echo "==> 9) Rede (VPC default, subnets, security group)..."
VPC_ID=$(aws ec2 describe-vpcs --region "$REGION" \
  --filters "Name=isDefault,Values=true" --query "Vpcs[0].VpcId" --output text)
SUBNETS=$(aws ec2 describe-subnets --region "$REGION" \
  --filters "Name=vpc-id,Values=$VPC_ID" \
  --query "Subnets[].SubnetId" --output text | tr '\t' ',')
SG_ID=$(aws ec2 create-security-group --region "$REGION" \
  --group-name helloworld-sg --description "SG helloworld ECS" \
  --vpc-id "$VPC_ID" --query "GroupId" --output text 2>/dev/null) || \
SG_ID=$(aws ec2 describe-security-groups --region "$REGION" \
  --filters "Name=group-name,Values=helloworld-sg" "Name=vpc-id,Values=$VPC_ID" \
  --query "SecurityGroups[0].GroupId" --output text)
aws ec2 authorize-security-group-ingress --region "$REGION" \
  --group-id "$SG_ID" --protocol tcp --port "$APP_PORT" --cidr 0.0.0.0/0 \
  2>/dev/null || true
echo "    VPC=$VPC_ID  SG=$SG_ID"

echo "==> 10) Service Fargate (1 task, IP publico)..."
aws ecs create-service --cluster "$CLUSTER" --service-name "$SERVICE" \
  --task-definition "$FAMILY" --desired-count 1 --launch-type FARGATE \
  --network-configuration "awsvpcConfiguration={subnets=[$SUBNETS],securityGroups=[$SG_ID],assignPublicIp=ENABLED}" \
  --region "$REGION" >/dev/null \
  || aws ecs update-service --cluster "$CLUSTER" --service "$SERVICE" \
       --task-definition "$FAMILY" --force-new-deployment --region "$REGION" >/dev/null

echo ""
echo "============================================================"
echo "Deploy disparado. Aguarde ~1-2 min a task ficar RUNNING."
echo ""
echo "Descobrir o IP publico:"
echo "  TASK=\$(aws ecs list-tasks --cluster $CLUSTER --region $REGION --query 'taskArns[0]' --output text)"
echo "  ENI=\$(aws ecs describe-tasks --cluster $CLUSTER --tasks \$TASK --region $REGION \\"
echo "    --query 'tasks[0].attachments[0].details[?name==\`networkInterfaceId\`].value' --output text)"
echo "  aws ec2 describe-network-interfaces --network-interface-ids \$ENI --region $REGION \\"
echo "    --query 'NetworkInterfaces[0].Association.PublicIp' --output text"
echo ""
echo "Testar:  curl http://<IP_PUBLICO>:8080/hello"
echo "============================================================"
