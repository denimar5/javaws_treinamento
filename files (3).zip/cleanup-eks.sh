#!/usr/bin/env bash
# ============================================================
# Derruba TUDO. A ORDEM IMPORTA:
# apaga o Service primeiro (libera o Load Balancer da AWS),
# depois deleta o cluster. Se inverter, o LB fica orfao
# e continua sendo cobrado por semanas.
# ============================================================
set -e

REGION="us-east-2"
CLUSTER="helloworld-eks"

echo "==> 1) Removendo o Service (libera o Load Balancer)..."
kubectl delete svc helloworld --ignore-not-found

echo "    aguardando o LB ser desprovisionado..."
sleep 30

echo "==> 2) Deletando o cluster EKS (leva ~10-15 min)..."
eksctl delete cluster --name "$CLUSTER" --region "$REGION"

echo ""
echo "Cluster removido. Confira no console que a stack CloudFormation"
echo "'eksctl-${CLUSTER}-cluster' sumiu, e que nao sobrou nenhum"
echo "Load Balancer em EC2 > Load Balancers."
