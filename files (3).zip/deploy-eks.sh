#!/usr/bin/env bash
# ============================================================
# Cria o cluster EKS e publica a app helloworld.
# Rode na pasta onde estao os .yaml.
# ============================================================
set -e

# ---------- PARAMETROS ----------
REGION="us-east-2"
CLUSTER="helloworld-eks"
MODE="standard"   # "standard" (node group) ou "auto" (EKS Auto Mode)
# --------------------------------

if [ "$MODE" = "auto" ]; then
  CFG="cluster-auto.yaml"
else
  CFG="cluster-standard.yaml"
fi

echo "==> 1) Criando o cluster EKS (modo: $MODE)."
echo "    ATENCAO: isso leva ~15-20 minutos. Pode ir tomar um cafe."
eksctl create cluster -f "$CFG"

echo "==> 2) Apontando o kubectl para o cluster..."
aws eks update-kubeconfig --name "$CLUSTER" --region "$REGION"

echo "==> 3) Conferindo os nodes do cluster..."
kubectl get nodes

echo "==> 4) Aplicando o Deployment e o Service..."
kubectl apply -f deployment.yaml
kubectl apply -f service.yaml

echo "==> 5) Esperando o Deployment ficar pronto..."
kubectl rollout status deployment/helloworld --timeout=180s

echo "==> 6) Aguardando o Load Balancer ganhar endereco (1-3 min)..."
URL=""
for i in $(seq 1 30); do
  URL=$(kubectl get svc helloworld \
    -o jsonpath='{.status.loadBalancer.ingress[0].hostname}' 2>/dev/null || true)
  [ -n "$URL" ] && break
  sleep 10
done

echo ""
kubectl get svc helloworld
echo ""
echo "============================================================"
if [ -n "$URL" ]; then
  echo "App publicada! (o DNS do LB pode levar ~2 min pra resolver)"
  echo "    curl http://$URL/hello"
else
  echo "LB ainda provisionando. Pegue o endereco com:"
  echo "    kubectl get svc helloworld"
  echo "E teste:  curl http://<EXTERNAL-IP>/hello"
fi
echo ""
echo "Ver os pods:     kubectl get pods"
echo "Ver os logs:     kubectl logs deployment/helloworld"
echo ""
echo "!! IMPORTANTE: o EKS cobra por hora. Ao terminar, rode:"
echo "    ./cleanup-eks.sh"
echo "============================================================"
