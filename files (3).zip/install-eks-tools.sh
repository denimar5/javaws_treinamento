#!/usr/bin/env bash
# ============================================================
# Instala as ferramentas do EKS: kubectl + eksctl
# (rode na EC2 que ja tem o AWS CLI configurado)
# ============================================================
set -e

echo "==> Instalando kubectl..."
curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl"
sudo install -o root -g root -m 0755 kubectl /usr/local/bin/kubectl
rm -f kubectl
kubectl version --client

echo "==> Instalando eksctl..."
ARCH=amd64
PLATFORM=$(uname -s)_$ARCH
curl -sLO "https://github.com/eksctl-io/eksctl/releases/latest/download/eksctl_${PLATFORM}.tar.gz"
tar -xzf "eksctl_${PLATFORM}.tar.gz" -C /tmp && rm "eksctl_${PLATFORM}.tar.gz"
sudo mv /tmp/eksctl /usr/local/bin
eksctl version

echo ""
echo "Pronto. Confira o AWS CLI com:  aws sts get-caller-identity"
