# Exercício: rodar a app `helloworld` no Kubernetes (Amazon EKS)

Mesma imagem que você já tem no ECR
(`840986438181.dkr.ecr.us-east-2.amazonaws.com/helloworld:latest`),
agora rodando num cluster Kubernetes gerenciado em vez do ECS.

## Paralelo com o que você já fez no ECS

| ECS | EKS (Kubernetes) |
|---|---|
| Task Definition | Deployment (`deployment.yaml`) |
| Service | Deployment + replicas |
| IP público / ALB | Service tipo LoadBalancer (`service.yaml`) |
| Fargate (AWS gerencia nós) | **EKS Auto Mode** |
| EC2 launch type (você gerencia nós) | **EKS standard** (managed node group) |

## Arquivos

| Arquivo | O que faz |
|---|---|
| `install-eks-tools.sh` | Instala `kubectl` e `eksctl` |
| `cluster-standard.yaml` | Cluster com node group (você gerencia os nós) |
| `cluster-auto.yaml` | Cluster em Auto Mode (AWS gerencia tudo) |
| `deployment.yaml` | Roda a imagem, 2 réplicas, health check em `/health` |
| `service.yaml` | Expõe a app via Load Balancer da AWS |
| `deploy-eks.sh` | Cria o cluster e publica a app |
| `cleanup-eks.sh` | Derruba tudo (na ordem certa) |

## Passo a passo

```bash
chmod +x *.sh

# 1) Ferramentas (kubectl + eksctl)
./install-eks-tools.sh

# 2) Escolha o modo: edite MODE no topo do deploy-eks.sh
#    MODE="standard"  -> node group (recomendado p/ aprender)
#    MODE="auto"      -> Auto Mode (mais simples, igual ao Fargate)

# 3) Cria o cluster e publica (DEMORA ~15-20 min na criação)
./deploy-eks.sh

# 4) Ao terminar a aula, DERRUBE (senão continua cobrando):
./cleanup-eks.sh
```

## Comandos úteis depois de subir

```bash
kubectl get nodes              # nós do cluster
kubectl get pods               # pods da app
kubectl get svc helloworld     # endereço do Load Balancer (EXTERNAL-IP)
kubectl logs deployment/helloworld
kubectl scale deployment/helloworld --replicas=4   # escalar na hora
```

## Custos (leia antes de criar)

- O **control plane** do EKS custa ~US$ 0,10/h (~US$ 73/mês), independente
  do modo, enquanto o cluster existir.
- **Standard**: + as instâncias EC2 do node group (2x t3.small).
- **Auto Mode**: + um adicional de gerência por nó que a AWS provisiona.
- O **Load Balancer** também é cobrado por hora.

Por isso o `cleanup-eks.sh` apaga o Service **antes** do cluster: assim o
Load Balancer é liberado e não fica órfão cobrando depois que o cluster some.

## Permissões (IAM) — o ponto que mais trava

O `eksctl` usa **CloudFormation** e cria VPC, subnets, roles e o cluster,
então o usuário precisa de permissões amplas: `eks:*`, `ec2:*`,
`cloudformation:*`, `iam:*` (criar/passar roles). Como você já bateu em
`AccessDenied` no ECR e no ECS, é bem provável que precise de uma policy
forte aqui (em aula, normalmente `AdministratorAccess` na conta da turma).

Lembre do slide: **IAM diz se você entra no cluster; o RBAC do Kubernetes
diz o que você pode fazer dentro.** Quem cria o cluster vira admin
automaticamente. Se outro colega for usar `kubectl` no mesmo cluster e tomar
"forbidden", é porque o IAM dele não está mapeado — resolve-se com
**EKS Access Entries**:

```bash
aws eks create-access-entry --cluster-name helloworld-eks \
  --principal-arn arn:aws:iam::840986438181:user/<usuario> --region us-east-2
# e associe uma policy de acesso (ex.: AmazonEKSClusterAdminPolicy)
aws eks associate-access-policy --cluster-name helloworld-eks \
  --principal-arn arn:aws:iam::840986438181:user/<usuario> \
  --policy-arn arn:aws:eks::aws:cluster-access-policy/AmazonEKSClusterAdminPolicy \
  --access-scope type=cluster --region us-east-2
```

## Se algo não subir (troubleshooting)

- **Pods em `Pending`**: faltou recurso nos nós. Aumente o `instanceType`
  (ex.: `t3.medium`) ou o `desiredCapacity` no `cluster-standard.yaml`.
- **`EXTERNAL-IP` fica em `<pending>`**: o LB demora 1-3 min. Se não vier no
  modo Auto, pode precisar de annotation do AWS Load Balancer; me avise.
- **`kubectl` dá "Unauthorized/forbidden"**: é o caso do Access Entry acima.
- **Imagem não puxa (`ImagePullBackOff`)**: confirme que o cluster e o ECR
  estão na mesma conta/região; o node role precisa de
  `AmazonEC2ContainerRegistryReadOnly` (vem por padrão no node group).

## Conta/região

Tudo aponta para `us-east-2` / conta `840986438181` (a mesma do seu ECR).
Se a aula for em outra conta, ajuste `region` nos `.yaml`, `REGION` nos
scripts e o `image` no `deployment.yaml`.
